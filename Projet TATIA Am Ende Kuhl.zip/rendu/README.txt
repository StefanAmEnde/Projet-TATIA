lien vers le repository du projet: https://github.com/StefanAmEnde/Projet-TATIA

L'implémentation se trouve dans le fichier 'projet tatia.ipynb'
Pour l'exécuter il est nécessaire que vous suivez les pas suivants (github ne permet pas de mettre en ligne des fichiers plus grand que 100 Mo):
- Téléchargez le modèle word2vec: https://drive.google.com/file/d/0B7XkCwpI5KDYNlNUTTlSS21pQmM/edit?resourcekey=0-wjGZdNAUop6WykTtMip30g
- Extrayez le fichier et mettez le dans le dossier 'models'
- Téléchargez le modèle T5 entraîné: https://drive.google.com/file/d/1--0NoHA7vTgeSsQ8OZ7FFPfdhawMRmCy/view?usp=sharing
- Mettez le aussi dans le dossier 'models'

L'entraînement du modèle a été réalisé sur google colab: https://colab.research.google.com/drive/1BdAVPAP2BRabjtPKfQiKA3wsE8tEUZ1T?usp=sharing